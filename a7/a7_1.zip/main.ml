open Parser;;
open New;;

let read_file f =
    let buffer = Lexing.from_channel (open_in f) in
        Parser.main Lexer.read buffer
;;

let query p q =
    let buffer = Lexing.from_string q in
        let goals = Parser.goal Lexer.read buffer in
            New.solve p goals
;;

let rec main p=
    Printf.printf ">>> ";
    let q = read_line() in
        if q="halt." then exit 0
        else begin
            query p q;
            main p
        end
;;
let runforever =
    main (read_file (Sys.argv.(1)))
;;

